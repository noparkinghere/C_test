#include <stdio.h>

int main()
{
	char c, d;
	printf("input number\n");
	c = getchar();
	d = getchar();
	printf("%c\t%c", c, d);
}
