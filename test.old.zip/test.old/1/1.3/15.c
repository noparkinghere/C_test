/*
 *
 * print sin function 
 *
 */
