#ifndef __MYFILE_H
#define __MYFILE_H
#include <stdio.h>

#define N 100

typedef enum
{
	a = 10,
	b = 20
}hello;

typedef struct 
{
	int a;
	char b;
	double c;
}num;
#endif
