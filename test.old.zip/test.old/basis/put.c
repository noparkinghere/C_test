#include <stdio.h>
#include "myfile.h"
void put()
{
	printf("%d", N);
}
