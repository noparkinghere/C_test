/*
 *
 * headfile.h test
 *
 */

#include <stdio.h>
#include "myfile.h"
#include "myfile.h"
int main()
{
	put();
}
