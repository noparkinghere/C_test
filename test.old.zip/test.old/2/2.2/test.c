/*
 *
 *
 *
 */
#include <graphics.h>
#include <stdio.h>

int main()
{
	printf("__line__");

}
